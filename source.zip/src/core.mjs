// Semantic grammar: shared concepts + speech act + visible referent.
// No character replacement, Chinese sentence tokenization, or hidden quiz score.
export const SIGNS={flow:'M4 10Q9 3 14 10T24 10M4 20Q9 13 14 20T24 20',material:'M7 4V27M15 4V27M23 4V27M4 11H26M4 20H26',care:'M3 16L11 7L20 16L11 25Z M10 16L19 7L27 16L19 25',ask:'M7 7H21V17L14 24M14 29h0',offer:'M4 22L15 8L26 22M8 27H22',memory:'M6 25V8L14 4L22 8V25M6 18H22M14 10V26',ack:'M5 17L12 24L25 7',place:'M5 6H25V26H5ZM15 12V20M11 16H19'};
export function speak(concept,act='ask',shared=false){
 if(!['flow','material','memory','place'].includes(concept)||!['ask','offer','ack'].includes(act))throw Error('Unknown semantic intent');
 return [...(shared?['care']:[]),concept,act];
}
export const RECORDS={
 thirsty:{title:'岸边 · 空水壶',signs:speak('flow'),body:'阿澜指着空水壶，又指向岸边那位扶着额头的船工。她把壶口轻轻碰了碰嘴唇。',icon:'water'},
 well:{title:'水井 · 两个容器',signs:speak('flow','ask',true),body:'弥叔提起井桶，先向畜槽倒水，再装满自己的壶。孩子跳过了畜槽，也被他轻轻拦下。',icon:'well'},
 offer:{title:'水井 · 伸过来的桶',signs:speak('flow','offer',true),body:'弥叔把桶柄转向你，给你留出站的位置。与阿澜的话相比，末尾的形状不同。',icon:'water'},
 aid:{title:'岸边 · 不同的先后',signs:speak('flow','ack'),body:'阿澜先让疲惫的船工喝水。弥叔张了张嘴，又提起空桶去补满畜槽。他们交换了几个急促的符号，随后一起扶他坐下。',icon:'water'},
 timber:{title:'木料棚 · 缺口',signs:speak('material'),body:'禾叶拿起一块木板，比了比你船上的缺口。她说话的末尾，和阿澜指着空壶时一样。',icon:'timber'},
 share:{title:'木料棚 · 相同的结',signs:speak('material','offer',true),body:'棚梁上、井边、另一艘修好的船上，都有同一个交叠的图案。禾叶指了指木料，又把掌心朝向你。',icon:'timber'},
 mark:{title:'修船棚 · 停下的工具',signs:speak('place','ask',true),body:'禾叶指向别的船上的印记，然后把刻刀停在你的船头上方。刀还没落下。那是家人为你刻名字的地方。',icon:'name'},
 boundary:{title:'修船棚 · 换一个位置',signs:speak('memory','ack'),body:'你捂住旧名字，指向船侧。禾叶看了看你的手，把工具移到另一侧，再次停下来等你回应。',icon:'name'}
};
export const initial=()=>({version:1,water:false,trough:false,aided:false,timber:false,delivered:false,repaired:false,mark:null,ended:false,seen:[],notes:{},player:{x:22,y:27}});
export function restoreGame(raw){
 try{const v=JSON.parse(raw);if(v?.version!==1)return initial();const s=initial();
 for(const k of ['water','trough','aided','timber','delivered','repaired','ended'])s[k]=v[k]===true;
 s.mark=['side','bow','none'].includes(v.mark)?v.mark:null;
 s.seen=Array.isArray(v.seen)?[...new Set(v.seen.filter(id=>Object.hasOwn(RECORDS,id)))]:[];
 if(v.notes&&typeof v.notes==='object')for(const id of s.seen)if(typeof v.notes[id]==='string')s.notes[id]=v.notes[id].slice(0,600);
 if(Number.isFinite(v.player?.x)&&Number.isFinite(v.player?.y))s.player={x:v.player.x,y:v.player.y};
 if(s.repaired&&(!s.aided||!s.delivered||!s.mark))s.repaired=false;
 if(s.ended&&!s.repaired)s.ended=false;if(s.delivered)s.timber=false;if(!s.repaired)s.mark=null;return s;
 }catch{return initial()}
}
export function remember(s,id){if(!Object.hasOwn(RECORDS,id))throw Error('Unknown observation');if(!s.seen.includes(id))s.seen.push(id);}
export function transition(s,action){
 const n=structuredClone(s);let event;
 switch(action){
 case 'observe_thirst':remember(n,'thirsty');event='thirsty';break;
 case 'observe_well':remember(n,'well');event='well';break;
 case 'ask_help':if(n.water){event='already_full';break;}remember(n,'offer');n.trough=true;n.water=true;event='together';break;
 case 'fill_trough':if(n.trough){event='trough_full';break;}n.trough=true;remember(n,'well');event='trough';break;
 case 'fill_flask':if(n.water){event='already_full';}else if(!n.trough){remember(n,'well');event='wait_water';}else{n.water=true;event='filled';}break;
 case 'give_water':if(n.aided){event='already_aided';}else if(!n.water){event='empty';}else{n.water=false;n.aided=true;remember(n,'aid');event='aided';}break;
 case 'observe_timber':remember(n,'timber');remember(n,'share');event='timber';break;
 case 'take_timber':if(n.delivered){event='already_delivered';}else if(n.timber){event='already_carrying';}else{n.timber=true;remember(n,'share');event='taken';}break;
 case 'give_timber':if(!n.timber){event=n.delivered?'already_delivered':'no_timber';}else{n.timber=false;n.delivered=true;event='delivered';}break;
 case 'inspect_mark':remember(n,'mark');event='mark';break;
 case 'show_name':remember(n,'boundary');event='boundary';break;
 case 'mark_side':case 'mark_bow':case 'mark_none':
  if(n.repaired){event='already_repaired';break;}if(!n.aided||!n.delivered){event='not_ready';break;}
  n.mark=action.slice(5);n.repaired=true;event='repaired';break;
 case 'sail':if(n.repaired){n.ended=true;event='ended';}else event='not_ready';break;
 default:throw Error('Unknown action '+action);
 }
 return {state:n,event};
}
export function objective(s){return s.ended?'船已修好 · 可以继续探索':s.repaired?'回到岸边，看看修好的船':!s.aided?'岸边有人需要帮助':!s.delivered?'找一块合适的木料，带去修船棚':'和禾叶商量船上的标记'};
export function hintFor(s){return s.repaired?'打开“去哪里”，回到搁浅的小船。':!s.aided?'去井边看看。居民会示范；你也可以把空壶递给他，请他一起帮忙。':!s.delivered?'木料棚就在修船棚旁。拿到木料后，交给禾叶。':'留意禾叶把刻刀停在什么地方。你可以出示旧名牌，也可以拒绝刻印。'};
