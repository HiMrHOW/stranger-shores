const $=id=>document.getElementById(id),canvas=$('world'),ctx=canvas.getContext('2d');
const STORE='stranger-shores.v1';let saved=null;try{saved=localStorage.getItem(STORE);}catch{}
let state=restoreGame(saved),player={...state.player,dir:0};
if(!canWalk(Math.round(player.x),Math.round(player.y)))player={x:22,y:27,dir:0};
let started=false,active=null,path=[],arrival=null,keys=new Set(),stick={x:0,y:0},moving=false,camera={x:0,y:0},clock=0,last=0,toastTimer,saveTimer;
const images={};
function icon(name){const c=document.createElement('canvas');c.width=c.height=16;c.setAttribute('aria-hidden','true');const g=c.getContext('2d');g.imageSmoothingEnabled=false;paintObject(g,name,0,0,name==='water'&&state.water);return c;}
function glyphs(tokens,element){element.replaceChildren();for(const token of tokens){if(!SIGNS[token])continue;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 30 34');svg.classList.add('glyph');svg.setAttribute('aria-hidden','true');const p=document.createElementNS('http://www.w3.org/2000/svg','path');p.setAttribute('d',SIGNS[token]);svg.append(p);element.append(svg);}}
function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,3200);}
function save(){state.player={x:player.x,y:player.y};try{localStorage.setItem(STORE,JSON.stringify(state));$('save-state').textContent='旅途已保存在本机';}catch{$('save-state').textContent='当前浏览器无法保存';}}
function hud(){
 const tasks=journey(state);$('progress-count').textContent=tasks.filter(t=>t.done).length+' / '+tasks.length+' 件事已完成 · 点“旅途”查看';
 $('objective').textContent=objective(state);$('chapter').textContent=state.repaired?'四 · 潮水正好':state.delivered?'三 · 你的名字':state.aided?'二 · 共同的东西':'一 · 陌生的声音';$('note-count').textContent=state.seen.length;
 const inventory=$('inventory');inventory.replaceChildren();for(const [name,label,on]of[['water',state.water?'一壶清水':'空水壶',true],['timber',state.delivered?'木料已交付':state.timber?'携带木料':'木料未取得',state.timber||state.delivered],['name','家人的名牌',true]]){const e=document.createElement('span');e.className='item'+(on?'':' inactive');e.append(icon(name),document.createTextNode(label));inventory.append(e);}
}
function actGame(action){const before=state.seen.length,previous=journey(state),result=transition(state,action);state=result.state;save();hud();const completed=journey(state).filter((t,i)=>t.done&&!previous[i].done);const feedback={trough:'✓ 水槽已添好；你的水壶还没装水',delivered:'✓ 木料已交付；还需要确认刻印',wait_water:'尚未取到水 · 先观察水井旁的动作'};if(completed.length){toast('✓ 已完成：'+completed.map(t=>t.label).join('、'));chime();}else if(feedback[result.event])toast(feedback[result.event]);else if(state.seen.length>before){toast('已记下见闻 · 这不代表任务已完成');chime();}return result.event;}
function seen(id){if(!state.seen.includes(id)){remember(state,id);save();hud();}}
function modalOpen(){return [...document.querySelectorAll('dialog')].some(d=>d.open);}
function pause(){path=[];arrival=null;keys.clear();stick={x:0,y:0};pointer=null;$('stick').firstElementChild.style.transform='';}
function closeInteraction(){active=null;demonstration=null;$('interaction').hidden=true;canvas.focus();}
function button(label,fn,iconName,emphasis=false,disabled=false){const b=document.createElement('button');if(iconName)b.append(icon(iconName));b.append(document.createTextNode(label));if(emphasis)b.classList.add('emphasis');b.onclick=fn;b.disabled=disabled;return b;}
function panel(title,role,signs,observation,actions,demo=null){pause();$('speaker').textContent=title;$('kind').textContent=role;glyphs(signs,$('utterance'));$('utterance').hidden=!signs.length;$('observation').textContent=observation;$('actions').replaceChildren();for(const a of actions)$('actions').append(button(...a));$('interaction').hidden=false;mountDemonstration($('demo'),demo);updateTaskStatus(demo);$('interaction').scrollTop=0;$('near').hidden=true;}
function response(signs,text,back,demo=null,backLabel='返回互动选项'){panel(active?.name||'你看见', '动作与回应',signs,text,[[backLabel,back],['先离开',closeInteraction]],demo);}
function updateTaskStatus(demo){
 const target=active?.id,status=target?placeProgress(state,target):null,box=$('task-status'),next=$('next-step');
 box.hidden=!status;next.hidden=true;if(!status)return;
 box.textContent=demo?.onComplete?'进行中 · 动作完成后才计入任务':demo&&!Array.isArray(demo)?'仅观看示范 · 不会自动完成取水':status.text;
 box.dataset.state=demo?.onComplete?'waiting':status.marker;
 const destination=nextPlace(state),place=targets.find(t=>t.id===destination);
 if(place&&destination!==target&&!demo?.onComplete){next.hidden=false;next.textContent='下一步：前往'+place.name;next.onclick=()=>walkTo(destination);}
}
function performWater(action,back){
 const preview=transition(state,action);
 const messages={already_full:'你的壶已经满了，不需要再倒水。',trough_full:'水槽已经添满了，不必继续倒。',wait_water:'弥叔托住桶底，指向空槽。他把桶放回，让你先看他的动作。'};
 if(messages[preview.event]){response(speak('flow','ask',true),messages[preview.event],back,preview.event==='wait_water'?{mode:'observe'}:null);return;}
 const mode=action==='fill_trough'?'trough':action==='fill_flask'?'flask':'together';
 panel('井边的弥叔','取水进行中',speak('flow','offer',true),mode==='together'?'你们扶稳井桶，先看好要倒向的容器。':'你接过井桶，扶稳桶柄。',[
  ['取消取水',back]
 ],{mode,initialTrough:state.trough?1:0,onComplete:()=>{
  actGame(action);response(speak('flow','ack',true),action==='fill_trough'?'水槽添好了。你把桶扶正，水流停下。':action==='fill_flask'?'水壶逐渐装满。你扶正井桶，收好水壶。':'你们一起扶正井桶。水槽和你的水壶都已经添好。',back);
 }});
}
function openTarget(id){const target=targets.find(t=>t.id===id);if(!target)return;active=target;pause();const back=()=>openTarget(id);
 if(id==='shore'){
  seen('thirsty');panel('岸边的阿澜','她看向你的水壶',speak('flow',state.aided?'ack':'ask'),state.aided?'船工的呼吸平稳了。阿澜把空壶还给你，向北边的修船棚指了指。':'她晃了晃一只空壶，碰了碰嘴唇，又指向扶着额头的船工。',[
   [state.aided?'看看船工的情况':state.water?'把水递给船工':'出示自己的空壶',()=>{const e=actGame('give_water');response(e==='aided'||e==='already_aided'?speak('flow','ack'):speak('flow'),e==='already_aided'?'船工已经缓过来了，向你点点头。你的水留在自己壶里。':e==='aided'?RECORDS.aid.body:'她把壶倒过来。没有水。她看向村里的井，做了一个提桶的动作。',back,e==='aided'?[['water','先给船工'],['well','再补水槽']]:null);},'water',true],
   ['再看她的动作',()=>response(speak('flow'),RECORDS.thirsty.body,back,[['water','空壶'],['hand','碰嘴唇'],['water','指船工']])],['先去岛上看看',closeInteraction]]);
 }else if(id==='well'){
  panel('井边的弥叔','他将桶放在两个容器之间',speak('flow','ask',true),state.trough?'畜槽里已经有水。弥叔松开桶柄，给你让了一个位置。':'井边放着一只水槽。一个孩子刚要把水提走，弥叔轻轻拦住了他。',[
   ['站在一旁，看看他们怎么做',()=>{actGame('observe_well');response(RECORDS.well.signs,'看桶口朝向哪里，再看看水落进了哪个容器。',back,{mode:'observe'});},'well'],
   [state.trough?'✓ 水槽已添好':'把井水倒进畜槽',()=>performWater('fill_trough',back),'water',false,state.trough],
   [state.water?'✓ 水壶已装满':'装满自己的水壶',()=>performWater('fill_flask',back),'water',!state.water,state.water],
   [state.water?'✓ 已有一壶水，无需再帮忙':'把空壶递过去，请他一起帮忙',()=>performWater('ask_help',back),'hand',false,state.water],['离开水井',closeInteraction]]);
 }else if(id==='timber'){
  seen('timber');seen('share');panel('堆放的木料','棚梁和水井上有相同的图案',speak('material','offer',true),'禾叶拿起一块木板，朝你船的方向比划。她把木板放回，掌心向你摊开。',[
   [state.delivered?'看看剩下的木料':state.timber?'抱好手中的木料':'拿起那块木板',()=>{const e=actGame('take_timber');response(speak('material','ack',true),e==='already_delivered'?'你已经把需要的木料交给禾叶。剩下的板材留在架上。':e==='already_carrying'?'你已经抱着一块木板，不需要再拿。':'你抱起一块干燥的木板。禾叶指向修船棚，挪开门边的工具给你让路。',back);},'timber',true],
   ['看看图案，又指向水井',()=>response(RECORDS.share.signs,RECORDS.share.body,back,[['well','水井'],['timber','木料棚'],['boat','别人的船']])],['放下手，先离开',closeInteraction]]);
 }else if(id==='workshop'){
  seen('timber');
  if(state.repaired){panel('修船工禾叶','船的裂缝已经补好了',speak('material','ack',true),'她沿着新木板敲了两下。远处的阿澜把船推回浅水，朝你招手。',[['回岸边看看船',()=>{closeInteraction();walkTo('boat');},'boat',true],['再看看她的工具',()=>response(speak('material','ack'),'刻刀安静地放在桌上。你们商量好的位置，没有被改变。',back)],['先离开',closeInteraction]]);return;}
  if(state.aided&&state.delivered){seen('mark');panel('修船工禾叶','刻刀停在船头上方',speak('place','ask',true),RECORDS.mark.body,[
   ['出示旧名牌，再指向船侧',()=>{actGame('show_name');panel('禾叶','她把工具移到另一侧',speak('memory','ack'),RECORDS.boundary.body,[['点头：就在船侧',()=>finishRepair('side'),'name',true],['摇头：不留下新标记',()=>finishRepair('none')],['再想一想',back]]);},'name',true],
   ['指向船头，点头',()=>panel('禾叶','她指向旧名字，再看你',speak('place','ask'),'新标记会刻在旧名字旁边。她仍等着你点头，不会盖掉原来的名字。',[['再点一次头',()=>finishRepair('bow'),'name',true],['收回手，换个位置',back]])],
   ['摆手，把工具轻轻推回去',()=>finishRepair('none')],['暂时离开',closeInteraction]]);return;}
  panel('修船工禾叶','她比划着船上的缺口',speak('material'),!state.aided?'她指了指岸边那位疲惫的船工，又看向你的水壶。然后，她继续比划需要补上的木板。':state.delivered?'合适的木料已经放在工作台上。':'她把两块短木板拼在一起，又摇摇头，指向旁边棚里的长木料。',[
   [state.timber?'把木料交给她':'出示双手，指向缺口',()=>{const e=actGame('give_timber');response(speak('material',e==='delivered'?'ack':'ask'),e==='delivered'?'她接过木料，贴着缺口量了量。长度刚好。':e==='already_delivered'?'她拍了拍工作台上的木料，又朝岸边指去。':'她拿起身旁的木板，重复了那个短短的表达，再指向东边的木料棚。',back);},'timber',true],['看看隔壁的木料棚',()=>{closeInteraction();walkTo('timber');},'timber'],['先离开',closeInteraction]]);
 }else if(id==='boat'){
  if(state.repaired){panel('你的船','新木板紧紧嵌在裂缝里',speak('material','ack',true),state.mark==='side'?'船侧多了那个交叠的标记。船头的旧名字仍然清楚。':state.mark==='bow'?'两个标记并排留在船头：家人的名字，以及岛上常见的交叠图案。':'船头只留下家人的名字。禾叶没有刻下新图案，但修补得同样仔细。',[['推船下水，向他们挥手',()=>{actGame('sail');showEnding();},'boat',true],['我还想留一会儿',closeInteraction]]);
  }else panel('搁浅的小船','船头的字是家人亲手刻的',[], '船底裂开了一道口子。你能在这里停留，但还不能离开。岸边有人朝你招手。',[[state.aided?'去修船棚看看':'走向岸边的人',()=>{closeInteraction();walkTo(state.aided?'workshop':'shore');},'boat',true],['摸摸旧名牌',()=>response([], '你认得这些磨损的笔画。岛上的人不认得，但这不意味着它们可以被随意抹掉。',back)],['继续走走',closeInteraction]]);
 }
}
function finishRepair(mark){actGame('mark_'+mark);response(speak('material','ack',true),mark==='none'?'她看懂了你的摆手，把刻刀收回。你们一起托住木板，船工把缝补牢了。':'她等你点头，才落下刻刀。新木板嵌入裂缝，旧名字没有被碰到。',()=>{closeInteraction();walkTo('boat');},[['timber','托住木板'],['hand','一起修好'],['boat','回到岸边']],'去岸边看修好的船');}
function showEnding(){closeInteraction();pause();$('ending-title').textContent=state.mark==='side'?'留在另一侧的记号':state.mark==='bow'?'并排的两个名字':'没有刻下的印记';$('ending-body').textContent=state.mark==='side'?'你保留了家人的名字，也带走了岛上共同照看的记号。\n那个曾让你困惑的交叠图案，现在有了一段属于你的经历。':state.mark==='bow'?'家人的名字旁，多了一枚陌生的记号。\n你知道它不只是木板上的花纹，也不一定能被一个词说清。':'你没有接受新标记。他们仍然帮你修好了船。\n离开不需要以放弃自己的名字为条件。';glyphs(speak('flow','offer',true),$('ending-sign'));$('ending').hidden=false;chime();}
function nearest(){return targets.map(t=>({...t,d:Math.hypot(t.x-player.x,t.y-player.y)})).filter(t=>t.d<2.25).sort((a,b)=>a.d-b.d)[0];}
function walkTo(id){const t=targets.find(t=>t.id===id);if(!started||!t)throw Error('还不能前往这个地点');closeInteraction();for(const [x,y]of[[t.x,t.y+1],[t.x-1,t.y],[t.x+1,t.y],[t.x,t.y-1]]){const p=route(player.x,player.y,x,y);if(p){path=p;arrival=id;if(!p.length){arrival=null;openTarget(id);}return;}}toast('小路被挡住了，换个方向试试。');}
function drawTile(atlas,index,x,y,w=16,h=16){ctx.drawImage(images[atlas],index%12*16,Math.floor(index/12)*16,16,16,Math.round(x),Math.round(y),w,h);}
function render(){
 ctx.imageSmoothingEnabled=false;
 const landscape=canvas.clientWidth>canvas.clientHeight;
 const cameraAnchor=active&&landscape ? .31 : .5;
 camera.x=Math.max(0,Math.min(W*T-canvas.width,player.x*T-canvas.width*cameraAnchor));
 camera.y=Math.max(0,Math.min(H*T-canvas.height,player.y*T-canvas.height*(active&&!landscape ? .25 : .5)));
 ctx.fillStyle='#387c87';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.save();ctx.translate(-Math.floor(camera.x),-Math.floor(camera.y));
 const x0=Math.max(0,Math.floor(camera.x/T)),x1=Math.min(W,Math.ceil((camera.x+canvas.width)/T)),y0=Math.max(0,Math.floor(camera.y/T)),y1=Math.min(H,Math.ceil((camera.y+canvas.height)/T));
 for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
  const t=terrain[y][x];if(t>=0)drawTile('town',t,x*T,y*T);else{const f=Math.sin(clock/1000+x*.6+y*.9);ctx.fillStyle=f>.3?'#5a9c9f':'#448e96';if((x+y)%3===0)ctx.fillRect(x*T+3+Math.round(f*2),y*T+8,6,1);}
 }
 const all=[...props.map(p=>({...p,kind:'prop'})),...targets.map(p=>({...p,kind:'target'})),{...player,kind:'player'}].sort((a,b)=>a.y-b.y);
 for(const p of all){if(p.x<x0-1||p.x>x1||p.y<y0-1||p.y>y1+2)continue;if(p.kind==='prop'&&((p.x===10&&(p.y===15||p.y===16))||(p.x===14&&p.y===16)))continue;
  if(p.kind==='player'){
   ctx.fillStyle='#183e3548';ctx.fillRect(Math.round(p.x*T)+3,Math.round(p.y*T)+13,10,3);const col=p.dir===0?0:p.dir===3?1:2,row=moving?Math.floor(clock/160)%3:0;
   ctx.save();ctx.translate(Math.round(p.x*T)+(p.dir===1?16:0),Math.round(p.y*T));if(p.dir===1)ctx.scale(-1,1);ctx.drawImage(images.villager,col*T,row*T,16,16,0,0,16,16);ctx.restore();
   if(state.timber){ctx.fillStyle='#714c34';ctx.fillRect(Math.round(p.x*T)-2,Math.round(p.y*T)+9,21,5);ctx.fillStyle='#d1a572';ctx.fillRect(Math.round(p.x*T)-2,Math.round(p.y*T)+10,21,2);}else if(state.water){ctx.fillStyle='#e9d4a5';ctx.fillRect(Math.round(p.x*T)+12,Math.round(p.y*T)+9,4,6);ctx.fillStyle='#77d0d9';ctx.fillRect(Math.round(p.x*T)+13,Math.round(p.y*T)+11,2,3);}
  }else if(p.tall)ctx.drawImage(images.town,p.tile%12*16,0,16,32,p.x*T,(p.y-1)*T,16,32);
  else{if(p.id==='timber')paintObject(ctx,'timber',p.x*T,p.y*T);else if(p.id==='boat'){ctx.save();ctx.translate(p.x*T,(p.y-1)*T);ctx.scale(1,2);paintObject(ctx,'boat');ctx.restore();}else drawTile(p.atlas,p.tile,p.x*T,p.y*T);if(p.kind==='target'){
   if(p.id==='boat'){ctx.fillStyle=state.repaired?'#e7c185':'#263f3e';ctx.fillRect(p.x*T+3,p.y*T+4,state.repaired?10:5,2);if(state.mark&&state.mark!=='none'){ctx.save();ctx.translate(p.x*T+(state.mark==='side'?11:5),p.y*T+(state.mark==='side'?3:-10));ctx.scale(.16,.16);ctx.strokeStyle='#eff5d3';ctx.lineWidth=4;ctx.stroke(new Path2D(SIGNS.care));ctx.restore();}}
   const status=placeProgress(state,p.id),mx=p.x*T+8,my=p.y*T-(p.id==='boat'?23:8);
   ctx.fillStyle=status.marker==='done'?'#d5edca':status.marker==='ready'?'#ffdfa0':'#c3d0cf';ctx.fillRect(mx-5,my-6,10,10);
   ctx.fillStyle='#274c43';ctx.strokeStyle='#274c43';ctx.lineWidth=1.5;
   if(status.marker==='done'){ctx.beginPath();ctx.moveTo(mx-3,my-1);ctx.lineTo(mx-1,my+1);ctx.lineTo(mx+3,my-3);ctx.stroke();}
   else if(status.marker==='ready'){ctx.fillRect(mx-1,my-4,2,4);ctx.fillRect(mx-1,my+1,2,1);}
   else for(let i=-3;i<=3;i+=3)ctx.fillRect(mx+i,my-1,1,1);
  }}
 }
 // These props reflect actual actions, not the replay running in the notebook panel.
 ctx.fillStyle='#695443';ctx.fillRect(160,242,2,23);ctx.fillRect(175,242,2,23);ctx.fillRect(160,242,17,3);ctx.fillStyle='#d7c69b';ctx.fillRect(168,245,1,12);ctx.fillStyle='#9aa79a';ctx.fillRect(159,258,20,13);ctx.fillStyle='#c3cebc';ctx.fillRect(158,256,22,4);ctx.fillStyle='#314d4b';ctx.fillRect(162,256,14,2);ctx.fillStyle='#6b8276';ctx.fillRect(160,265,18,1);ctx.fillRect(166,260,1,5);ctx.fillRect(173,266,1,5);
 ctx.fillStyle='#71513d';ctx.fillRect(14*T,16*T+6,20,10);ctx.fillStyle=state.trough?'#71c4d1':'#3f4337';ctx.fillRect(14*T+2,16*T+8,16,5);
 if(state.trough){ctx.fillStyle='#c8eeee';ctx.fillRect(14*T+3,16*T+8,9,1);}
 for(const [x,y]of [[14*T+5,16*T-6],[36*T+3,15*T-12]]){ctx.save();ctx.translate(x,y);ctx.scale(.3,.3);ctx.strokeStyle='#fff0ba';ctx.lineWidth=3;ctx.stroke(new Path2D(SIGNS.care));ctx.restore();}
 if(state.delivered&&!state.repaired){ctx.fillStyle='#d0a06a';ctx.fillRect(33*T,14*T+4,21,4);ctx.fillStyle='#725138';ctx.fillRect(33*T,14*T+7,21,1);}
 if(path.length){const [x,y]=path[path.length-1];ctx.strokeStyle='#fff0be';ctx.lineWidth=1;ctx.strokeRect(x*T+3,y*T+4,10,8);}
 ctx.restore();
}
function frame(now){const dt=Math.min((now-last)/1000,.04);last=now;clock=now;moving=false;
 if(started&&!document.hidden&&!active&&!modalOpen()&&$('ending').hidden){let dx=stick.x+(keys.has('d')||keys.has('arrowright')?1:0)-(keys.has('a')||keys.has('arrowleft')?1:0),dy=stick.y+(keys.has('s')||keys.has('arrowdown')?1:0)-(keys.has('w')||keys.has('arrowup')?1:0);
  if(Math.hypot(dx,dy)>.12){path=[];arrival=null;}else if(path.length){const [x,y]=path[0],distance=Math.hypot(x-player.x,y-player.y);if(distance<.085){player.x=x;player.y=y;path.shift();}else{dx=(x-player.x)/distance;dy=(y-player.y)/distance;}}
  if(Math.hypot(dx,dy)>.1){const n=Math.hypot(dx,dy),speed=Math.min(4.1*dt,path.length?Math.hypot(path[0][0]-player.x,path[0][1]-player.y):Infinity);dx/=n;dy/=n;const xx=player.x+dx*speed,yy=player.y+dy*speed;if(canWalk(Math.round(xx),Math.round(player.y)))player.x=xx;if(canWalk(Math.round(player.x),Math.round(yy)))player.y=yy;moving=true;player.dir=Math.abs(dx)>Math.abs(dy)?dx>0?1:2:dy>0?0:3;}
  if(!path.length&&arrival){const id=arrival;arrival=null;openTarget(id);}
  const n=nearest();$('near').hidden=!n||!!active;if(n)$('near').textContent='触碰 · '+n.name;
  $('place').textContent=player.y>23?'南湾 · 搁浅处':player.x<18?'村中 · 共用水井':'北岸 · 修船棚';
 }
 if(images.town){render();drawDemonstration(dt);}requestAnimationFrame(frame);
}
function resize(){const r=$('stage').getBoundingClientRect();canvas.width=r.width<600?320:480;canvas.height=Math.max(160,Math.round(canvas.width*r.height/r.width));ctx.imageSmoothingEnabled=false;}
canvas.addEventListener('pointerdown',e=>{if(!started||active||modalOpen()||!$('ending').hidden)return;const r=canvas.getBoundingClientRect(),x=((e.clientX-r.left)/r.width*canvas.width+camera.x)/T,y=((e.clientY-r.top)/r.height*canvas.height+camera.y)/T;const t=targets.find(t=>Math.hypot(t.x+.5-x,t.y+.5-y)<1.3);if(t){walkTo(t.id);return;}const p=route(player.x,player.y,Math.floor(x),Math.floor(y));if(p){path=p;arrival=null;}canvas.focus();});
function interact(){if(!started||modalOpen()||!$('ending').hidden)return;if(active){closeInteraction();return;}const n=nearest();if(n)openTarget(n.id);else toast('靠近有亮点的人或物件，也可以用“去哪里”。');}
$('near').onclick=$('touch-action').onclick=interact;$('close-interaction').onclick=closeInteraction;
let pointer=null;const joystick=$('stick');function updateStick(e){const r=joystick.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,n=Math.hypot(dx,dy),scale=Math.min(1,32/(n||1));stick={x:dx*scale/32,y:dy*scale/32};joystick.firstElementChild.style.transform=`translate(${dx*scale}px,${dy*scale}px)`;}
joystick.onpointerdown=e=>{if(!started||active||modalOpen())return;e.preventDefault();pointer=e.pointerId;joystick.setPointerCapture(pointer);updateStick(e);};joystick.onpointermove=e=>{if(e.pointerId===pointer)updateStick(e);};joystick.onpointerup=joystick.onpointercancel=joystick.onlostpointercapture=()=>{pointer=null;stick={x:0,y:0};joystick.firstElementChild.style.transform='';};
window.addEventListener('keydown',e=>{
 const key=e.key.toLowerCase();
 if(key==='escape'){if(modalOpen()){for(const d of document.querySelectorAll('dialog[open]'))d.close();}else closeInteraction();pause();return;}
 if(['INPUT','TEXTAREA','BUTTON','SUMMARY'].includes(e.target.tagName)||modalOpen())return;
 if(!started||!$('ending').hidden)return;
 if(key.startsWith('arrow')||key===' ')e.preventDefault();
 if((key==='e'||key===' ')&&!e.repeat)interact();else if(key==='j'&&!e.repeat)openBook();else if(!active)keys.add(key);
});window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
function clearHeldInput(){keys.clear();stick={x:0,y:0};pointer=null;$('stick').firstElementChild.style.transform='';if(started)save();}
window.addEventListener('blur',clearHeldInput);document.addEventListener('visibilitychange',clearHeldInput);window.addEventListener('pagehide',()=>{if(started)save();});window.addEventListener('resize',resize);
function openBook(){if(!started){toast('先从岸边醒来，再记下见闻。');return;}pause();const root=$('book-content');root.replaceChildren();if(!state.seen.length){const p=document.createElement('p');p.textContent='还没有见闻。走近岸边的人，看看他们指向什么。';root.append(p);}for(const id of state.seen){const record=RECORDS[id],e=document.createElement('section');e.className='entry';const h=document.createElement('h3');h.textContent=record.title;const signs=document.createElement('div');signs.className='recorded-sign';glyphs(record.signs,signs);const p=document.createElement('p');p.textContent=record.body;const label=document.createElement('label');label.textContent='我的猜想（可以改，也可以有不止一种）';const input=document.createElement('textarea');input.maxLength=600;input.value=state.notes[id]||'';input.placeholder='这些符号，可能和什么有关？';input.oninput=()=>{state.notes[id]=input.value;clearTimeout(saveTimer);saveTimer=setTimeout(save,300);};label.append(input);e.append(h,signs,p,label);root.append(e);} $('book').showModal();}
$('notebook').onclick=openBook;
function openJourney(){
 if(!started){toast('先开始旅途。');return;}pause();
 const list=$('journey-list');list.replaceChildren();
 const tasks=journey(state),current=tasks.find(t=>!t.done);
 for(const task of tasks){
  const entry=document.createElement('div');entry.className='journey-entry';entry.dataset.done=String(task.done);
  const title=document.createElement('strong');title.textContent=(task.done?'✓ 已完成':task===current?'→ 当前这件事':'○ 尚未完成')+' · '+task.label;
  const detail=document.createElement('small');detail.textContent=task.detail;entry.append(title,detail);list.append(entry);
 }
 const root=$('destinations');root.replaceChildren();
 for(const t of targets){const status=placeProgress(state,t.id),b=document.createElement('button');b.className='travel-button';b.dataset.state=status.marker;
 const name=document.createElement('span');name.textContent=t.name;const small=document.createElement('small');small.textContent=status.text;
 b.append(name,small);b.onclick=()=>{$('travel').close();walkTo(t.id);};root.append(b);}
 $('travel').showModal();
}
$('map-button').onclick=openJourney;
for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>$(b.dataset.close).close();$('help').onclick=()=>{pause();$('help-dialog').showModal();};$('hint').onclick=()=>{$('help-dialog').close();toast(hintFor(state));};
function startGame(fresh){if(fresh){state=initial();player={...state.player,dir:0};}started=true;$('intro').hidden=true;$('ending').hidden=true;hud();save();if(!state.seen.length){active={name:'你醒来时'};panel('潮水退去之后','你的船还不能出海',[],'木板裂了，水壶也空了。岸边的人朝你招手。先走过去，看看她想做什么。',[['起身，走向岸边的人',()=>{closeInteraction();walkTo('shore');},'hand',true],['我想自己走走',closeInteraction]]);}canvas.focus();}
$('start').onclick=()=>{if(saved&&state.seen.length)$('confirm-reset').showModal();else startGame(true);};$('resume').onclick=()=>startGame(false);$('keep-exploring').onclick=()=>{$('ending').hidden=true;};$('new-journey').onclick=$('reset').onclick=()=>{$('help-dialog').close();$('confirm-reset').showModal();};$('confirm-new').onclick=()=>{for(const d of document.querySelectorAll('dialog[open]'))d.close();pause();closeInteraction();startGame(true);};
let audio=null,audioOn=false;function chime(){if(!audio||!audioOn)return;const now=audio.currentTime;for(const [i,f]of[392,523,659].entries()){const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.value=f;g.gain.setValueAtTime(.001,now+i*.12);g.gain.linearRampToValueAtTime(.025,now+i*.12+.025);g.gain.exponentialRampToValueAtTime(.001,now+i*.12+.7);o.connect(g);g.connect(audio.destination);o.start(now+i*.12);o.stop(now+i*.12+.8);}}
$('sound').onclick=async()=>{try{audio??=new(window.AudioContext||window.webkitAudioContext)();await audio.resume();audioOn=!audioOn;$('sound').textContent=audioOn?'声音 开':'声音 关';$('sound').setAttribute('aria-pressed',String(audioOn));chime();}catch{toast('当前浏览器无法播放声音，仍可正常游玩。');}};
Promise.all(Object.entries(ASSETS).map(([name,url])=>new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>{images[name]=i;resolve();};i.onerror=reject;i.src=url;}))).then(()=>{$('loading').hidden=true;$('intro').hidden=false;$('resume').hidden=!state.seen.length;hud();resize();requestAnimationFrame(frame);}).catch(()=>{$('loading').textContent='画面未能载入，请刷新重试。';});
setInterval(()=>{if(started&&!document.hidden)save();},6000);
if(document.modelContext?.registerTool){
 const lifetime=new AbortController();
 try{Promise.resolve(document.modelContext.registerTool({
  name:'walk_to_island_place',title:'走向岛上的地点',
  description:'与“去哪里”按钮使用相同的寻路。角色实际行走到地点后打开互动，不会代替玩家选择行动或结局。',
  inputSchema:{type:'object',properties:{destination:{type:'string',enum:targets.map(t=>t.id)}},required:['destination'],additionalProperties:false},
  annotations:{readOnlyHint:false,untrustedContentHint:false},
  execute(input){
   if(!input||Object.keys(input).length!==1||!targets.some(t=>t.id===input.destination))throw Error('未知地点');
   if(!started||modalOpen()||!$('ending').hidden)throw Error('请先开始游戏并关闭弹窗');
   walkTo(input.destination);return {destination:input.destination,walking:path.length>0};
  }
 },{signal:lifetime.signal})).catch(()=>{});window.addEventListener('pagehide',()=>lifetime.abort(),{once:true});}catch{}
}
