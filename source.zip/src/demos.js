let demonstration=null;
function mountDemonstration(root,spec){
 demonstration=null;root.replaceChildren();root.hidden=!spec;if(!spec)return;
 if(Array.isArray(spec)){
  for(const [name,label]of spec){const item=document.createElement('div');item.className='demo-step';item.append(icon(name),document.createTextNode(label));root.append(item);}return;
 }
 const film=document.createElement('canvas');film.width=192;film.height=80;film.className='observation-film';film.setAttribute('role','img');
 const label=document.createElement('p');label.className='film-label';label.textContent=spec.onComplete?'正在取水 · 完成后放入背包，离开则取消':'动作示范 · 不改变你的背包和岛上的水槽';
 const caption=document.createElement('p');caption.className='film-caption';caption.setAttribute('aria-live','polite');
 const controls=document.createElement('div');controls.className='film-controls';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const d=demonstration={film,caption,elapsed:0,playing:!reduced,lastCaption:'',sequence:waterSequence(spec.mode,spec.initialTrough||0),live:!!spec.onComplete,onComplete:spec.onComplete};
 const toggle=button(reduced?'播放动作':'暂停动作',()=>{if(d.elapsed>=d.sequence.duration)d.elapsed=0;d.playing=!d.playing;refresh();});
 const next=button('下一动作',()=>{d.playing=false;d.elapsed=d.sequence.checkpoints.find(t=>t>d.elapsed+.001)??d.sequence.duration;drawDemonstration(0);refresh();});
 const replay=button('从头看',()=>{d.elapsed=0;d.playing=!reduced;drawDemonstration(0);refresh();});
 function refresh(){toggle.textContent=d.playing?'暂停动作':d.elapsed>=d.sequence.duration?'重新播放':'播放动作';next.disabled=d.elapsed>=d.sequence.duration;}
 d.refresh=refresh;controls.append(toggle,next);if(!d.live)controls.append(replay);
 root.append(label,film,caption,controls);drawDemonstration(0);
}
function drawDemonstration(dt){
 const d=demonstration;if(!d||!active||$('interaction').hidden)return;
 if(d.playing&&!modalOpen()&&!document.hidden)d.elapsed=Math.min(d.sequence.duration,d.elapsed+Math.max(0,dt));
 const s=waterFrame(d.sequence,d.elapsed);d.sample=s;
 if(d.lastCaption!==s.caption){d.caption.textContent=s.caption;d.film.setAttribute('aria-label',s.caption);d.lastCaption=s.caption;}
 const g=d.film.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#73946b';g.fillRect(0,0,192,80);g.fillStyle='#c4b082';g.fillRect(0,49,192,31);
 const tile=(atlas,id,x,y)=>g.drawImage(images[atlas],id%12*16,Math.floor(id/12)*16,16,16,Math.round(x),Math.round(y),24,24);
 g.fillStyle='#665344';g.fillRect(17,22,3,33);g.fillRect(38,22,3,33);g.fillRect(17,22,24,4);
 if(s.kind==='lift'){g.fillStyle='#cbbb91';g.fillRect(28,26,1,Math.max(0,s.bucketY-30));}
 g.fillStyle='#9ba99d';g.fillRect(15,45,28,18);g.fillStyle='#c3cebc';g.fillRect(14,44,30,5);g.fillStyle='#344e4b';g.fillRect(19,44,20,3);g.fillStyle='#6f827b';g.fillRect(16,55,26,1);g.fillRect(23,49,1,6);g.fillRect(33,56,1,6);
 g.fillStyle='#6b5140';g.fillRect(88,50,37,16);g.fillStyle='#403f37';g.fillRect(91,52,31,9);
 const troughHeight=8*s.trough;
 if(troughHeight>0){g.fillStyle='#70c9d5';g.fillRect(91,61-troughHeight,31,troughHeight);}
 g.fillStyle='#d7c59b';g.fillRect(159,47,10,15);g.fillRect(161,43,6,5);g.fillStyle='#584e42';g.fillRect(162,43,4,3);g.fillRect(161,49,6,11);
 if(s.flask>0){g.fillStyle='#65baca';g.fillRect(161,60-10*s.flask,6,10*s.flask);}
 if(d.live&&d.sequence.mode!=='together')g.drawImage(images.villager,0,0,16,16,Math.round(s.actorX),29,24,24);else tile('dungeon',100,s.actorX,29);
 if(d.sequence.mode==='together'){
  g.drawImage(images.villager,0,0,16,16,Math.round(s.bucketX+6),24,24,24);
  g.strokeStyle='#d7b58c';g.lineWidth=2;g.beginPath();g.moveTo(s.bucketX+9,40);g.lineTo(s.bucketX+4,s.bucketY);g.stroke();
 }
 // The pivot, lip and stream share a single transform.
 g.strokeStyle='#d7b58c';g.lineWidth=2;g.beginPath();g.moveTo(s.actorX+17,43);g.lineTo(s.bucketX-4,s.bucketY+1);g.stroke();
 g.save();g.translate(s.bucketX,s.bucketY);g.rotate(s.angle);
 g.strokeStyle='#d5d3b6';g.lineWidth=1;g.beginPath();g.arc(0,-5,4,Math.PI,0);g.stroke();
 g.beginPath();g.moveTo(-5,-5);g.lineTo(5,-5);g.lineTo(4,6);g.lineTo(-4,6);g.closePath();g.fillStyle='#785f48';g.fill();g.save();g.clip();
 g.rotate(-s.angle);g.fillStyle='#80cad0';g.fillRect(-12,6-11*s.bucket,24,14);g.restore();
 g.strokeStyle='#d1ab77';g.stroke();g.fillStyle='#d1ab77';g.fillRect(-5,-6,10,2);g.restore();
 if(s.stream){
  const bottom=s.stream.target==='trough'?61-troughHeight:44;
  const startY=s.mouth.y+(bottom-s.mouth.y)*s.stream.tail,endY=s.mouth.y+(bottom-s.mouth.y)*s.stream.head;
  g.strokeStyle='#b6eeea';g.lineWidth=1.5;g.beginPath();g.moveTo(s.mouth.x,startY);g.lineTo(s.mouth.x,endY);g.stroke();
 }
 g.save();g.translate(107,9);g.scale(.4,.4);g.strokeStyle='#fff0bd';g.lineWidth=2;g.stroke(new Path2D(SIGNS.care));g.restore();
 g.fillStyle='#456c60';g.fillRect(15,73,162,2);g.fillStyle='#ffedaf';g.fillRect(15,73,162*s.elapsed/d.sequence.duration,2);
 if(s.done){d.playing=false;d.refresh();if(d.onComplete){const complete=d.onComplete;d.onComplete=null;complete();}}
}
