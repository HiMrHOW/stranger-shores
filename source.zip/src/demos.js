// A replay of an observed action, never a word-for-word translation.
let demonstration=null;
function mountDemonstration(root,steps){
 demonstration=null;root.replaceChildren();root.hidden=!steps;if(!steps)return;
 if(active?.id!=='well'){
  for(const [name,label]of steps){const item=document.createElement('div');item.className='demo-step';item.append(icon(name),document.createTextNode(label));root.append(item);}return;
 }
 const film=document.createElement('canvas');film.width=192;film.height=76;film.className='observation-film';film.setAttribute('role','img');
 const caption=document.createElement('p');caption.className='film-caption';caption.setAttribute('aria-live','polite');
 const controls=document.createElement('div');controls.className='film-controls';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 demonstration={film,caption,elapsed:0,playing:!reduced,step:-1};
 const toggle=button(reduced?'播放动作':'暂停动作',()=>{demonstration.playing=!demonstration.playing;toggle.textContent=demonstration.playing?'暂停动作':'播放动作';});
 const next=button('下一步',()=>{demonstration.playing=false;demonstration.elapsed=((Math.floor(demonstration.elapsed/2400)+1)%3)*2400;toggle.textContent='播放动作';drawDemonstration(0);});
 const replay=button('重看',()=>{demonstration.elapsed=0;drawDemonstration(0);});
 controls.append(toggle,next,replay);root.append(film,caption,controls);drawDemonstration(0);
}
function drawDemonstration(dt){
 const d=demonstration;if(!d||!active||$('interaction').hidden)return;
 if(d.playing&&!modalOpen()&&!document.hidden)d.elapsed=(d.elapsed+dt*1000)%7200;
 const step=Math.floor(d.elapsed/2400),f=(d.elapsed%2400)/2400;
 const captions=['他从井里提起一桶水。','他先把水倒进旁边的共用水槽。','水槽有水后，他才装满自己的壶。'];
 if(d.step!==step){d.caption.textContent=`${step+1} / 3 · ${captions[step]}`;d.film.setAttribute('aria-label',captions[step]);d.step=step;}
 const g=d.film.getContext('2d');g.imageSmoothingEnabled=false;g.fillStyle='#73946b';g.fillRect(0,0,192,76);g.fillStyle='#c4b082';g.fillRect(0,49,192,27);
 const tile=(atlas,id,x,y)=>g.drawImage(images[atlas],id%12*16,Math.floor(id/12)*16,16,16,Math.round(x),Math.round(y),24,24);
 g.fillStyle='#665344';g.fillRect(17,22,3,33);g.fillRect(38,22,3,33);g.fillRect(17,22,24,4);g.fillStyle='#cbbb91';g.fillRect(28,26,1,18);
 g.fillStyle='#9ba99d';g.fillRect(15,45,28,18);g.fillStyle='#c3cebc';g.fillRect(14,44,30,5);g.fillStyle='#344e4b';g.fillRect(19,44,20,3);g.fillStyle='#6f827b';g.fillRect(16,55,26,1);g.fillRect(23,49,1,6);g.fillRect(33,56,1,6);
 // The trough has a persistent rim and a visibly rising water surface.
 g.fillStyle='#6b5140';g.fillRect(88,50,37,16);g.fillStyle='#403f37';g.fillRect(91,52,31,9);
 if(step>0){g.fillStyle='#70c9d5';const h=step===2?8:Math.max(1,Math.round(f*8));g.fillRect(91,61-h,31,h);g.fillStyle='#ceeee0';g.fillRect(93,61-h,14,1);}
 const x=step===0?43:step===1?43+Math.min(1,f*2)*24:67+Math.min(1,f*2)*64;
 tile('dungeon',100,x,29);
 // Bucket travels with the resident; the stream makes the action legible.
 const bx=step===0?x+15:x+21,by=step===0?35-Math.sin(f*Math.PI)*9:38;
 g.strokeStyle='#d5d3b6';g.strokeRect(Math.round(bx+1),Math.round(by-4),7,6);g.fillStyle='#785f48';g.fillRect(Math.round(bx),Math.round(by),10,10);g.fillStyle='#9de0e0';g.fillRect(Math.round(bx+2),Math.round(by+1),6,2);
 if(step>0&&f>.45){g.fillStyle='#b6eeea';g.fillRect(Math.round(bx+9),Math.round(by+5),2,step===1?12:8);}
 g.fillStyle='#d7c59b';g.fillRect(159,47,10,15);g.fillRect(162,43,4,5);g.fillStyle=step===2&&f>.45?'#65baca':'#584e42';g.fillRect(161,51,6,9);
 // Shared sign stays attached to the trough, not a translated label.
 g.save();g.translate(101,28);g.scale(.45,.45);g.strokeStyle='#fff0bd';g.lineWidth=2;g.stroke(new Path2D(SIGNS.care));g.restore();
 for(let i=0;i<3;i++){g.fillStyle=i===step?'#ffedaf':'#456c60';g.fillRect(83+i*10,6,6,3);}
}
