export const W=46,H=34,T=16;
export const terrain=Array.from({length:H},()=>Array(W).fill(-1));
export const props=[];
const solids=new Set();const k=(x,y)=>x+','+y;
let seed=721;function rng(){seed=seed*16807%2147483647;return seed/2147483647;}
for(let y=2;y<H-3;y++)for(let x=3;x<W-3;x++){
 const nx=(x-23)/21,ny=(y-16)/15;
 if(nx*nx+ny*ny<1+(Math.sin(y*.8)*.025)){terrain[y][x]=rng()<.12?1:0;}
}
function prop(x,y,tile,atlas='town',solid=true,tall=false){props.push({x,y,tile,atlas,tall});if(solid)solids.add(k(x,y));}
function road(x,y,w,h){for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)if(terrain[j]?.[i]!==undefined)terrain[j][i]=25;}
road(21,10,3,20);road(9,17,27,3);road(11,10,3,10);road(31,11,3,13);
function house(x,y,w,warm){for(let j=0;j<4;j++)for(let i=0;i<w;i++){
 let tile=j<2?48+(warm?4:0)+j*12+(i===0?0:i===w-1?2:1):(j===2?72:84)+(i===w-1?3:0);
 if(i===Math.floor(w/2))tile=j===2?74:j===3?85:tile;prop(x+i,y+j,tile);
}road(x+Math.floor(w/2),y+4,2,3);}
house(6,9,5,true);house(28,6,7,true);house(16,5,5,false);
for(let y=2;y<H-3;y++)for(let x=3;x<W-3;x++)if(terrain[y][x]===0&&!solids.has(k(x,y))&&rng()<.075)prop(x,y,rng()<.6?28:27);
for(const [x,y]of[[7,7],[13,7],[25,6],[38,10],[37,23],[9,22],[15,26],[29,26],[35,7]])if(terrain[y][x]>=0)prop(x,y,4,'town',true,true);
for(let x=8;x<13;x++)prop(x,25,80);
for(const [x,y]of[[8,23],[10,23],[12,23],[19,12],[37,18],[28,22]])prop(x,y,2,'town',false);
// Dock planks are actual atlas cells, not a flattened scene illustration.
for(let y=28;y<33;y++)for(let x=21;x<=24;x++)terrain[y][x]=25;
export const targets=[
 {id:'shore',name:'岸边的阿澜',place:'南湾 · 搁浅处',x:20,y:25,tile:99,atlas:'dungeon',role:'她扶着一位疲惫的船工'},
 {id:'well',name:'井边的弥叔',place:'村中 · 共用水井',x:12,y:16,tile:100,atlas:'dungeon',role:'桶、壶，还有一只水槽'},
 {id:'workshop',name:'修船工禾叶',place:'北岸 · 修船棚',x:32,y:13,tile:98,atlas:'dungeon',role:'她正在整理修船工具'},
 {id:'timber',name:'堆放的木料',place:'北岸 · 木料棚',x:36,y:15,tile:103,atlas:'town',role:'棚梁上有一个交叠的印记'},
 {id:'boat',name:'搁浅的小船',place:'南湾 · 旧码头',x:23,y:30,tile:104,atlas:'town',role:'船头还留着家人刻下的名字'}
];
prop(10,15,57);prop(10,16,69);prop(14,16,107);solids.add(k(15,16));
for(const p of targets){solids.add(k(p.x,p.y));for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
 if(dx===0&&dy===0)continue;const x=p.x+dx,y=p.y+dy;terrain[y][x]=25;solids.delete(k(x,y));for(let i=props.length-1;i>=0;i--)if(props[i].x===x&&props[i].y===y)props.splice(i,1);
}}
// Add the sailor after clearing interaction approaches; otherwise he vanishes.
prop(19,26,97,'dungeon');
solids.add(k(23,29)); // Upper half of the boat is not walkable.
const dirt=terrain.map(row=>row.map(t=>t===25));
for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++)if(dirt[y][x])terrain[y][x]=(!dirt[y-1][x]?12:!dirt[y+1][x]?36:24)+(!dirt[y][x-1]?0:!dirt[y][x+1]?2:1);
export function canWalk(x,y){return Number.isInteger(x)&&Number.isInteger(y)&&x>=0&&y>=0&&x<W&&y<H&&terrain[y][x]>=0&&!solids.has(k(x,y));}
export function route(sx,sy,tx,ty){sx=Math.round(sx);sy=Math.round(sy);if(!canWalk(tx,ty))return null;const q=[[sx,sy]],previous=new Map([[k(sx,sy),null]]);for(let at=0;at<q.length;at++){
 const [x,y]=q[at];if(x===tx&&y===ty){let point=[x,y];const p=[];while(point){p.push(point);point=previous.get(k(...point));}return p.reverse().slice(1);}
 for(const [dx,dy]of[[0,1],[1,0],[0,-1],[-1,0]]){const xx=x+dx,yy=y+dy,key=k(xx,yy);if(canWalk(xx,yy)&&!previous.has(key)){previous.set(key,[x,y]);q.push([xx,yy]);}}
}return null;}
