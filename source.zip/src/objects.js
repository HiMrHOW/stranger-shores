// Gameplay silhouettes: do not label a chest as a flask or a ladder as a boat.
function paintObject(g,name,x=0,y=0,filled=false){
 g.save();g.translate(Math.round(x),Math.round(y));
 const rect=(color,x,y,w,h)=>{g.fillStyle=color;g.fillRect(x,y,w,h);};
 if(name==='water'){
  rect('#785840',5,1,6,3);rect('#dfc69c',5,4,6,2);rect('#dfc69c',3,6,10,9);rect('#8b7155',4,7,8,7);if(filled)rect('#77c9d2',5,9,6,4);rect('#f4dfb8',4,6,2,2);
 }else if(name==='timber'){
  for(let i=0;i<3;i++){rect('#704d35',i%2,3+i*4,15,3);rect('#c69b64',i%2,3+i*4,14,2);}rect('#e5c687',5,3,2,11);
 }else if(name==='well'){
  rect('#695443',2,0,2,11);rect('#695443',12,0,2,11);rect('#b28f62',2,0,12,2);rect('#d7c69b',7,2,1,7);rect('#9aa79a',1,9,14,6);rect('#c3cebc',0,8,16,3);rect('#314d4b',3,8,10,2);rect('#6b8276',2,12,12,1);
 }else if(name==='boat'){
  rect('#624430',6,0,4,2);rect('#624430',3,2,10,2);rect('#624430',1,4,14,9);rect('#624430',3,13,10,2);rect('#bc8954',3,4,10,8);rect('#5c4938',5,4,6,8);rect('#d6b27b',2,7,12,2);rect('#d6b27b',5,12,6,2);
 }else if(name==='name'){
  rect('#705239',1,3,14,11);rect('#c29a68',2,4,12,9);rect('#f1d7a4',4,6,1,5);rect('#f1d7a4',7,6,4,1);rect('#f1d7a4',8,8,1,3);
 }else{rect('#dfba8e',5,6,7,7);rect('#dfba8e',5,2,2,7);rect('#dfba8e',8,1,2,8);rect('#dfba8e',11,3,2,7);rect('#dfba8e',2,7,3,3);}
 g.restore();
}
