// All progress UI is derived from saved facts, never from opening a conversation.
export function journey(s){
 return [
  {id:'water',label:'取得一壶水',done:s.water||s.aided,destination:'well',detail:s.aided?'水已送给船工':s.water?'水已经在背包里':s.trough?'水槽已添好，你的壶还没装水':'看示范不算取水；需要实际装满水壶'},
  {id:'aid',label:'把水送给船工',done:s.aided,destination:'shore',detail:s.aided?'船工已经喝到水，不用重复送':s.water?'水已备好，回岸边递给船工':'先取得水，再回岸边'},
  {id:'timber',label:'拿到修船木料',done:s.timber||s.delivered,destination:'timber',detail:s.delivered?'木料已经交给禾叶':s.timber?'木料在你手中，还需要交付':'从木料棚拿一块合适的木板'},
  {id:'repair',label:'和禾叶修好船',done:s.repaired,destination:'workshop',detail:s.repaired?'船已修好，刻印选择已确认':!s.aided?'船工还需要帮助':!s.delivered?s.timber?'把手中的木料交给禾叶':'先取得木料，再交给禾叶':'木料已交付，还需要确认刻印；拒绝也可以'},
  {id:'sail',label:'回船边告别',done:s.ended,destination:'boat',detail:s.ended?'这段旅途已完成，可以自由探索':s.repaired?'船已就绪，回船边选择告别':'先把船修好'}
 ];
}
export function nextPlace(s){
 if(s.ended)return null;
 if(!s.aided&&!s.seen.includes('thirsty')&&!s.water)return 'shore';
 return journey(s).find(task=>!task.done)?.destination||null;
}
export function placeProgress(s,id){
 const make=(done,ready,text)=>({done,marker:done?'done':ready?'ready':'waiting',text});
 if(id==='shore')return make(s.aided,!s.aided,s.aided?'已完成 · 船工已经喝到水':s.water?'可以完成 · 把背包里的水递给船工':'未完成 · 需要取水，再回来送水');
 if(id==='well')return make(s.water||s.aided,!s.water&&!s.aided,s.aided?'已完成 · 取水已用于救助；补水是可选的':s.water?'已完成 · 水在背包里，还没送给船工':s.trough?'进行中 · 水槽已添好，你的壶仍是空的':'未完成 · 看示范不会自动取得水');
 if(id==='timber')return make(s.timber||s.delivered,s.aided&&!s.timber&&!s.delivered,s.delivered?'已完成 · 木料已经交付':s.timber?'已完成 · 已拿到木料，还没交给禾叶':'未完成 · 木料还没有拿走');
 if(id==='workshop')return make(s.repaired,s.aided&&(s.timber||s.delivered),s.repaired?'已完成 · 船修好了，可以回岸边':!s.aided?'等待中 · 先帮助岸边的船工':!s.delivered?s.timber?'可以推进 · 把木料交给禾叶':'等待中 · 还缺木料':'进行中 · 木料已交付，刻印还没确认');
 return make(s.ended,s.repaired&&!s.ended,s.ended?'已完成 · 已告别，现在是自由探索':s.repaired?'可以完成 · 船已修好，等待你告别':'等待中 · 船还没修好');
}
