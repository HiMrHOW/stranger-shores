export function stickVector(dx,dy,radius=42,deadZone=7){
 const distance=Math.hypot(dx,dy),visual=Math.min(1,radius/(distance||1));
 const strength=Math.max(0,Math.min(1,(distance-deadZone)/(radius-deadZone)));
 return {x:distance?dx/distance*strength:0,y:distance?dy/distance*strength:0,knobX:dx*visual,knobY:dy*visual};
}
export function isWorldTap(start,end){return start.id===end.id&&Math.hypot(start.x-end.x,start.y-end.y)<=12&&end.time-start.time<650;}
export function pickTouchTarget(candidates,x,y){
 return candidates.map(t=>({...t,d:Math.hypot(t.screenX-x,t.screenY-y)})).filter(t=>t.d<=Math.max(26,t.radius)).sort((a,b)=>a.d-b.d)[0]||null;
}
export function shouldDismissSheet(dx,dy){return dy>=72&&Math.abs(dx)<dy*.8;}
