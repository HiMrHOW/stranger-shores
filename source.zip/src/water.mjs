// One timeline owns bucket pose, emission and delayed arrival of each drop.
export function waterSequence(mode='observe',initialTrough=0){
 if(!['observe','trough','flask','together'].includes(mode))throw Error('Unknown water sequence');
 const trough=mode==='observe'?0:Math.max(0,Math.min(1,initialTrough));
 const sequence={mode,initialTrough:trough,segments:[],duration:0,checkpoints:[0]};
 let pose={actorX:7,bucketX:28,bucketY:43,angle:0};
 function add(kind,duration,to,caption,target=null,volume=0){
  const start=sequence.duration,end=start+duration;
  sequence.segments.push({kind,start,end,from:{...pose},to:{...pose,...to},caption,target,volume});
  pose={...pose,...to};sequence.duration=end;
  if(kind==='pour')sequence.checkpoints.push(start+.8,start+1.6);
  sequence.checkpoints.push(end);
 }
 add('lift',1.2,{actorX:43,bucketX:61,bucketY:33},'把井桶从井口提起，握稳。');
 const destinations=[];
 if(mode!=='flask'&&trough<1)destinations.push({target:'trough',x:98,y:33,actorX:71,volume:.7*(1-trough),label:'共用水槽'});
 if(mode!=='trough')destinations.push({target:'flask',x:157,y:31,actorX:130,volume:.3,label:'水壶'});
 for(const dest of destinations){
  add('carry',1.2,{actorX:dest.actorX,bucketX:dest.x,bucketY:dest.y},`端着桶，走到${dest.label}旁边。`);
  add('tilt',.6,{angle:1.08},`把桶口朝向${dest.label}，慢慢倾斜。`,dest.target);
  add('pour',1.92,{},`水从倾斜的桶口流入${dest.label}。`,dest.target,dest.volume);
  add('recover',.6,{angle:0},'停止倒水，把桶扶正。',dest.target);
 }
 add('hold',.6,{},'动作完成。');return sequence;
}
export function waterFrame(sequence,seconds){
 const t=Math.max(0,Math.min(sequence.duration,Number.isFinite(seconds)?seconds:0));
 const segment=sequence.segments.find(s=>t<s.end)||sequence.segments.at(-1);
 const f=Math.min(1,Math.max(0,(t-segment.start)/(segment.end-segment.start))),ease=f*f*(3-2*f);
 const pose=Object.fromEntries(Object.keys(segment.from).map(k=>[k,segment.from[k]+(segment.to[k]-segment.from[k])*ease]));
 let emitted=0,receivedTrough=0,receivedFlask=0,stream=null;
 for(const s of sequence.segments.filter(s=>s.kind==='pour')){
  const age=t-s.start,emission=Math.max(0,Math.min(1,age/1.8)),received=Math.max(0,Math.min(1,(age-.12)/1.8));
  emitted+=emission*s.volume;
  if(s.target==='trough')receivedTrough+=received*s.volume;else receivedFlask+=received*s.volume;
  if(age>0&&age<1.92)stream={target:s.target,head:Math.min(1,age/.12),tail:Math.max(0,(age-1.8)/.12)};
 }
 const mouth={x:pose.bucketX+5*Math.cos(pose.angle)+5*Math.sin(pose.angle),y:pose.bucketY+5*Math.sin(pose.angle)-5*Math.cos(pose.angle)};
 return {...pose,mouth,stream,kind:segment.kind,caption:segment.caption,elapsed:t,done:t>=sequence.duration,bucket:Math.max(0,1-emitted),trough:Math.min(1,sequence.initialTrough+receivedTrough/.7),flask:Math.min(1,receivedFlask/.3),inFlight:Math.max(0,emitted-receivedTrough-receivedFlask)};
}
