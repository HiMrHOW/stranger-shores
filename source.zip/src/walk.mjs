// Atlas: columns 0/1 are front/back, 2 is a raised-arm action, 3 is right-facing locomotion.
// Never include column 2 in the walking cycle.
export function walkSprite(direction,distance,moving){
 const side=direction===1||direction===2;
 return {col:side?3:direction===3?1:0,row:moving?[0,1,2,1][Math.floor(distance/.55)%4]:0,flip:direction===2};
}
export function advanceWalk(distance,dx,dy){return distance+Math.hypot(dx,dy);}
