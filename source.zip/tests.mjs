import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {initial,transition,restoreGame,speak,RECORDS} from './src/core.mjs';
import {targets,canWalk,route} from './src/world.mjs';
for(const from of [{x:22,y:27},...targets.map(t=>({x:t.x,y:t.y+1}))])for(const to of targets){const p=route(from.x,from.y,to.x,to.y+1);assert.ok(p,`${from.x},${from.y} cannot reach ${to.id}`);assert.ok(p.every(([x,y])=>canWalk(x,y)));}
assert.equal(route(22,27,-1,-1),null);
let s=initial();const mistake=transition(s,'fill_flask');assert.equal(mistake.state.water,false);assert.equal(mistake.event,'wait_water');assert.equal(s.seen.length,0);
assert.equal(transition(s,'mark_side').state.repaired,false);
assert.equal(transition(s,'sail').state.ended,false);
for(const waterRoute of [['observe_well','fill_trough','fill_flask'],['ask_help']])for(const mark of ['side','bow','none']){
 let game=initial();for(const a of [...waterRoute,'give_water','observe_timber','take_timber','give_timber','inspect_mark','mark_'+mark,'sail'])game=transition(game,a).state;
 assert.equal(game.ended,true);assert.equal(game.mark,mark);assert.equal(game.timber,false);assert.equal(game.water,false);
 assert.deepEqual(restoreGame(JSON.stringify(game)),game);
}
assert.deepEqual(restoreGame('bad JSON'),initial());assert.equal(restoreGame('{"version":1,"repaired":true,"ended":true}').ended,false);
assert.notDeepEqual(speak('flow','ask'),speak('flow','offer'));assert.equal(speak('flow').at(-1),speak('material').at(-1));
assert.ok(Object.values(RECORDS).every(r=>r.signs.length>=2));
const html=fs.readFileSync(new URL('./dist/index.html',import.meta.url),'utf8');
for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
assert.equal(html.includes('/*CORE*/'),false);assert.ok(html.includes('data:image/png;base64,'));assert.ok(!/<script[^>]+src=/.test(html));
console.log('PASS: all-pairs reachability; mistakes recoverable; two water routes × three endings; save validation; semantic grammar; bundled JS syntax; self-contained assets.');
