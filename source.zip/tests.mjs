import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {initial,transition,restoreGame,speak,RECORDS} from './src/core.mjs';
import {targets,canWalk,route} from './src/world.mjs';
import {waterSequence,waterFrame} from './src/water.mjs';
for(const from of [{x:22,y:27},...targets.map(t=>({x:t.x,y:t.y+1}))])for(const to of targets){const p=route(from.x,from.y,to.x,to.y+1);assert.ok(p,`${from.x},${from.y} cannot reach ${to.id}`);assert.ok(p.every(([x,y])=>canWalk(x,y)));}
assert.equal(route(22,27,-1,-1),null);
let s=initial();const mistake=transition(s,'fill_flask');assert.equal(mistake.state.water,false);assert.equal(mistake.event,'wait_water');assert.equal(s.seen.length,0);
assert.equal(transition(s,'mark_side').state.repaired,false);
assert.equal(transition(s,'sail').state.ended,false);
for(const waterRoute of [['observe_well','fill_trough','fill_flask'],['ask_help']])for(const mark of ['side','bow','none']){
 let game=initial();for(const a of [...waterRoute,'give_water','observe_timber','take_timber','give_timber','inspect_mark','mark_'+mark,'sail'])game=transition(game,a).state;
 assert.equal(game.ended,true);assert.equal(game.mark,mark);assert.equal(game.timber,false);assert.equal(game.water,false);
 assert.deepEqual(restoreGame(JSON.stringify(game)),game);
}
assert.deepEqual(restoreGame('bad JSON'),initial());assert.equal(restoreGame('{"version":1,"repaired":true,"ended":true}').ended,false);
assert.notDeepEqual(speak('flow','ask'),speak('flow','offer'));assert.equal(speak('flow').at(-1),speak('material').at(-1));
assert.ok(Object.values(RECORDS).every(r=>r.signs.length>=2));
const html=fs.readFileSync(new URL('./dist/index.html',import.meta.url),'utf8');
for(const script of html.matchAll(/<script>([\s\S]*?)<\/script>/g))new vm.Script(script[1]);
assert.equal(html.includes('/*CORE*/'),false);assert.ok(html.includes('data:image/png;base64,'));assert.ok(!/<script[^>]+src=/.test(html));
console.log('PASS: all-pairs reachability; mistakes recoverable; two water routes × three endings; save validation; semantic grammar; bundled JS syntax; self-contained assets.');
// Exercise replay controls without real time, browser storage, or game mutations.
const fakeContext=new Proxy({}, {get:(_,key)=>key==='fillStyle'?null:()=>{}});
const element=()=>({children:[],hidden:false,style:{},setAttribute(){},replaceChildren(){this.children=[];},append(...items){this.children.push(...items);},getContext(){return fakeContext;}});
const replayRoot=element(), replayScope={waterSequence,waterFrame,document:{createElement:element,hidden:false},active:{id:'well'},$:()=>({hidden:false}),modalOpen:()=>false,matchMedia:()=>({matches:true}),button:(label,onclick)=>({textContent:label,onclick}),images:{town:{},dungeon:{},villager:{}},SIGNS:{care:''},Path2D:class{},icon:element};
vm.createContext(replayScope);vm.runInContext(fs.readFileSync(new URL('./src/demos.js',import.meta.url),'utf8'),replayScope);
replayScope.mountDemonstration(replayRoot,{mode:'observe'});
assert.match(replayRoot.children[2].textContent,/井口/);
replayScope.drawDemonstration(5);assert.match(replayRoot.children[2].textContent,/井口/);
replayRoot.children[3].children[1].onclick();assert.match(replayRoot.children[2].textContent,/端着桶/);
replayRoot.children[3].children[2].onclick();assert.match(replayRoot.children[2].textContent,/井口/);
replayRoot.children[3].children[0].onclick();replayScope.drawDemonstration(2.5);assert.match(replayRoot.children[2].textContent,/倾斜/);
replayScope.drawDemonstration(100);assert.equal(replayRoot.children[3].children[1].disabled,true);
replayScope.drawDemonstration(100);assert.match(replayRoot.children[2].textContent,/完成/); // No automatic emptying loop.
let commits=0;replayScope.matchMedia=()=>({matches:false});
replayScope.mountDemonstration(replayRoot,{mode:'trough',onComplete:()=>commits++});
replayScope.drawDemonstration(2);assert.equal(commits,0);
replayScope.mountDemonstration(replayRoot,null);replayScope.drawDemonstration(100);assert.equal(commits,0);
replayScope.mountDemonstration(replayRoot,{mode:'together',onComplete:()=>commits++});
replayScope.document.hidden=true;replayScope.drawDemonstration(100);assert.equal(commits,0);
replayScope.document.hidden=false;replayScope.drawDemonstration(100);replayScope.drawDemonstration(100);assert.equal(commits,1);
replayScope.mountDemonstration(replayRoot,null);assert.equal(replayRoot.hidden,true);
console.log('PASS: reduced-motion, pause/next/restart, no auto-loop, hidden-page pause, cancel does not commit, completion commits once.');
// Sweep every 10 ms rather than just checking whether captions changed.
for(const mode of ['observe','trough','flask','together'])for(const full of [0,1]){
 const seq=waterSequence(mode,full);let prior=waterFrame(seq,0);
 for(let t=.01;t<=seq.duration+.01;t+=.01){
  const frame=waterFrame(seq,t);
  assert.ok(frame.trough>=prior.trough-1e-9&&frame.flask>=prior.flask-1e-9,'water must not disappear');
  assert.ok(frame.trough-prior.trough<.01&&frame.flask-prior.flask<.01,'no instant filling');
  assert.ok(Math.abs(frame.bucket+.7*(frame.trough-seq.initialTrough)+.3*frame.flask+frame.inFlight-1)<1e-8,'water conservation');
  if(frame.stream){assert.ok(frame.angle>1,'stream requires tilted bucket');const [lo,hi]=frame.stream.target==='trough'?[91,122]:[162,166];assert.ok(frame.mouth.x>=lo&&frame.mouth.x<=hi,'stream must hit opening');}
  prior=frame;
 }
 for(const pour of seq.segments.filter(p=>p.kind==='pour')){
  const before=waterFrame(seq,pour.start),inAir=waterFrame(seq,pour.start+.1),landed=waterFrame(seq,pour.start+.4);
  assert.equal(inAir[pour.target],before[pour.target],'no rise before first drop lands');assert.ok(landed[pour.target]>before[pour.target]);
 }
 const end=waterFrame(seq,seq.duration+5);assert.ok(end.done);assert.equal(end.stream,null);assert.equal(end.angle,0);
}
let repeated=initial();for(const action of ['ask_help','give_water','ask_help'])repeated=transition(repeated,action).state;
assert.deepEqual(transition(repeated,'give_water').state,repeated);
assert.equal(transition(repeated,'ask_help').event,'already_full');assert.equal(transition(repeated,'fill_trough').event,'trough_full');
const carrying=transition(initial(),'take_timber').state;assert.equal(transition(carrying,'take_timber').event,'already_carrying');
let repaired=initial();for(const a of ['ask_help','give_water','take_timber','give_timber','mark_side'])repaired=transition(repaired,a).state;
assert.deepEqual(transition(repaired,'mark_bow').state,repaired);
assert.equal(restoreGame(JSON.stringify({...repaired,timber:true})).timber,false);
assert.equal(canWalk(19,26),false);assert.equal(canWalk(15,16),false);
console.log('PASS: 10ms choreography sweeps, tilted emission, lip alignment, arrival delay, gradual levels, water conservation, repeated actions and save invariants.');
