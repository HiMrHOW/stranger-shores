import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
let html=read('src/index.html');
for(const [placeholder,file] of [['STYLE','style.css'],['TOUCH_STYLE','touch.css'],['CORE','core.mjs'],['WORLD','world.mjs'],['WATER','water.mjs'],['TOUCH','touch.mjs'],['WALK','walk.mjs'],['PROGRESS','progress.mjs'],['OBJECTS','objects.js'],['DEMOS','demos.js'],['GAME','game.js']]){
 const source=read('src/'+file).replace(/^export /gm,'');
 html=html.replace('/*'+placeholder+'*/',()=>source);
}
const assets=Object.fromEntries(['town','dungeon','villager'].map(name=>[name,'data:image/png;base64,'+fs.readFileSync(path.join(root,'assets',name+'.png')).toString('base64')]));
html=html.replace('/*ASSETS*/',()=> 'const ASSETS='+JSON.stringify(assets)+';');
fs.mkdirSync(path.join(root,'dist'),{recursive:true});
fs.writeFileSync(path.join(root,'dist/index.html'),html);
console.log('Built self-contained index.html:',Buffer.byteLength(html),'bytes');
